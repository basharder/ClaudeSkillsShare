# Node Library Reference

Full JSON templates for all common n8n nodes used in Canarm/Matt workflows.
Read this file before writing any workflow JSON.

---

## Table of Contents

1. [Trigger Nodes](#trigger-nodes)
2. [Google Nodes](#google-nodes)
3. [HTTP / LMStudio Nodes](#http--lmstudio-nodes)
4. [Logic / Transform Nodes](#logic--transform-nodes)
5. [LMStudio Parse Pattern](#lmstudio-parse-pattern)
6. [CIBC CSV Parse Pattern](#cibc-csv-parse-pattern)
7. [Connection Format Reference](#connection-format-reference)

---

## Trigger Nodes

### Schedule Trigger — Monday 8 AM
```json
{
  "id": "UUID",
  "name": "Schedule Trigger",
  "type": "n8n-nodes-base.scheduleTrigger",
  "typeVersion": 1.2,
  "position": [250, 300],
  "parameters": {
    "rule": {
      "interval": [
        { "field": "cronExpression", "expression": "0 8 * * 1" }
      ]
    }
  }
}
```

### Manual Trigger
```json
{
  "id": "UUID",
  "name": "Manual Trigger",
  "type": "n8n-nodes-base.manualWorkflowTrigger",
  "typeVersion": 1,
  "position": [250, 300],
  "parameters": {}
}
```

### Webhook Trigger
```json
{
  "id": "UUID",
  "name": "Webhook",
  "type": "n8n-nodes-base.webhook",
  "typeVersion": 2,
  "position": [250, 300],
  "parameters": {
    "path": "your-webhook-path",
    "httpMethod": "POST",
    "responseMode": "onReceived"
  },
  "webhookId": "UUID"
}
```

---

## Google Nodes

### Google Sheets — Get All Rows
```json
{
  "id": "UUID",
  "name": "Read Sheet",
  "type": "n8n-nodes-base.googleSheets",
  "typeVersion": 4.5,
  "position": [500, 300],
  "parameters": {
    "operation": "getAll",
    "documentId": { "__rl": true, "value": "YOUR_SHEET_ID", "mode": "id" },
    "sheetName":  { "__rl": true, "value": "Sheet1",        "mode": "name" },
    "options": {}
  },
  "credentials": {
    "googleSheetsOAuth2Api": { "id": "CRED_ID", "name": "Google Sheets" }
  }
}
```

### Google Sheets — Append Row
```json
{
  "id": "UUID",
  "name": "Append to Sheet",
  "type": "n8n-nodes-base.googleSheets",
  "typeVersion": 4.5,
  "position": [500, 300],
  "parameters": {
    "operation": "append",
    "documentId": { "__rl": true, "value": "YOUR_SHEET_ID", "mode": "id" },
    "sheetName":  { "__rl": true, "value": "Sheet1",        "mode": "name" },
    "columns": {
      "mappingMode": "defineBelow",
      "value": {
        "mappingValues": [
          { "name": "ColumnHeader", "value": "={{ $json.field_name }}" }
        ]
      }
    },
    "options": {}
  },
  "credentials": {
    "googleSheetsOAuth2Api": { "id": "CRED_ID", "name": "Google Sheets" }
  }
}
```

### Google Sheets — Update Row (match on column value)
```json
{
  "id": "UUID",
  "name": "Mark Processed",
  "type": "n8n-nodes-base.googleSheets",
  "typeVersion": 4.5,
  "position": [500, 300],
  "parameters": {
    "operation": "update",
    "documentId": { "__rl": true, "value": "YOUR_SHEET_ID", "mode": "id" },
    "sheetName":  { "__rl": true, "value": "Sheet1",        "mode": "name" },
    "columns": {
      "mappingMode": "defineBelow",
      "value": {
        "matchingColumns": ["row_id"],
        "mappingValues": [
          { "name": "row_id",       "value": "={{ $json.row_id }}" },
          { "name": "status",       "value": "PROCESSED" },
          { "name": "processed_at", "value": "={{ $now.toISO() }}" }
        ]
      }
    },
    "options": {}
  },
  "credentials": {
    "googleSheetsOAuth2Api": { "id": "CRED_ID", "name": "Google Sheets" }
  }
}
```

### Google Drive — Search for Files
```json
{
  "id": "UUID",
  "name": "Find Files in Drive",
  "type": "n8n-nodes-base.googleDrive",
  "typeVersion": 3,
  "position": [500, 300],
  "parameters": {
    "operation": "fileSearch",
    "queryString": "mimeType='text/csv' and 'FOLDER_ID' in parents and trashed=false",
    "limit": 50,
    "options": {}
  },
  "credentials": {
    "googleDriveOAuth2Api": { "id": "CRED_ID", "name": "Google Drive" }
  }
}
```

### Google Drive — Download File
```json
{
  "id": "UUID",
  "name": "Download File",
  "type": "n8n-nodes-base.googleDrive",
  "typeVersion": 3,
  "position": [500, 300],
  "parameters": {
    "operation": "download",
    "fileId": { "__rl": true, "value": "={{ $json.id }}", "mode": "id" },
    "options": {}
  },
  "credentials": {
    "googleDriveOAuth2Api": { "id": "CRED_ID", "name": "Google Drive" }
  }
}
```

### Google Drive — Move File
```json
{
  "id": "UUID",
  "name": "Archive File",
  "type": "n8n-nodes-base.googleDrive",
  "typeVersion": 3,
  "position": [500, 300],
  "parameters": {
    "operation": "move",
    "fileId":   { "__rl": true, "value": "={{ $json.file_id }}", "mode": "id" },
    "folderId": { "__rl": true, "value": "YOUR_ARCHIVE_FOLDER_ID", "mode": "id" },
    "options": {}
  },
  "credentials": {
    "googleDriveOAuth2Api": { "id": "CRED_ID", "name": "Google Drive" }
  }
}
```

---

## HTTP / LMStudio Nodes

### HTTP Request — LMStudio (OpenAI-compatible)
```json
{
  "id": "UUID",
  "name": "Call LMStudio",
  "type": "n8n-nodes-base.httpRequest",
  "typeVersion": 4.2,
  "position": [500, 300],
  "parameters": {
    "method": "POST",
    "url": "http://YOUR_LMSTUDIO_HOST:PORT/v1/chat/completions",
    "sendBody": true,
    "contentType": "json",
    "body": {
      "model": "local-model",
      "temperature": 0.1,
      "max_tokens": 512,
      "messages": [
        {
          "role": "system",
          "content": "SYSTEM PROMPT HERE. Always return only valid JSON, no markdown, no backticks."
        },
        {
          "role": "user",
          "content": "=USER PROMPT HERE. Input: {{ $json.input_field }}"
        }
      ]
    },
    "options": {}
  }
}
```

### HTTP Request — Generic POST with Header Auth
```json
{
  "id": "UUID",
  "name": "API Call",
  "type": "n8n-nodes-base.httpRequest",
  "typeVersion": 4.2,
  "position": [500, 300],
  "parameters": {
    "method": "POST",
    "url": "https://api.example.com/endpoint",
    "authentication": "genericCredentialType",
    "genericAuthType": "httpHeaderAuth",
    "sendHeaders": true,
    "headerParameters": {
      "parameters": [
        { "name": "Authorization", "value": "Bearer {{ $env.API_KEY }}" },
        { "name": "Content-Type",  "value": "application/json" }
      ]
    },
    "sendBody": true,
    "contentType": "json",
    "body": {},
    "options": {}
  }
}
```

### Slack — Send Message
```json
{
  "id": "UUID",
  "name": "Send Slack",
  "type": "n8n-nodes-base.slack",
  "typeVersion": 2.2,
  "position": [500, 300],
  "parameters": {
    "resource": "message",
    "operation": "send",
    "channel": { "__rl": true, "value": "#channel-name", "mode": "name" },
    "text": "={{ $json.message }}"
  },
  "credentials": {
    "slackApi": { "id": "CRED_ID", "name": "Slack" }
  }
}
```

---

## Logic / Transform Nodes

### If — Check field not empty
```json
{
  "id": "UUID",
  "name": "Check Has Data",
  "type": "n8n-nodes-base.if",
  "typeVersion": 2,
  "position": [500, 300],
  "parameters": {
    "conditions": {
      "options": { "caseSensitive": false },
      "conditions": [
        {
          "id": "UUID",
          "leftValue":  "={{ $json.field_name }}",
          "rightValue": "",
          "operator": { "type": "string", "operation": "notEmpty" }
        }
      ],
      "combinator": "and"
    }
  }
}
```

### Filter — Keep only unprocessed rows
```json
{
  "id": "UUID",
  "name": "Filter Unprocessed",
  "type": "n8n-nodes-base.filter",
  "typeVersion": 2,
  "position": [500, 300],
  "parameters": {
    "conditions": {
      "options": { "caseSensitive": false },
      "conditions": [
        {
          "id": "UUID",
          "leftValue":  "={{ $json.status }}",
          "rightValue": "",
          "operator": { "type": "string", "operation": "isEmpty" }
        }
      ],
      "combinator": "and"
    }
  }
}
```

### Set Fields
```json
{
  "id": "UUID",
  "name": "Set Fields",
  "type": "n8n-nodes-base.set",
  "typeVersion": 3.4,
  "position": [500, 300],
  "parameters": {
    "mode": "manual",
    "duplicateItem": false,
    "assignments": {
      "assignments": [
        { "id": "UUID", "name": "field_name", "value": "field_value", "type": "string" }
      ]
    }
  }
}
```

---

## LMStudio Parse Pattern

Always follow an LMStudio HTTP node with this Code node to safely extract and parse the response:

```javascript
const items = $input.all();

return items.map(item => {
  // Carry forward any upstream fields needed downstream
  const upstreamField = item.json.upstream_field || '';

  try {
    // LMStudio OpenAI-compatible: choices[0].message.content
    const raw   = item.json.choices[0].message.content.trim();
    const clean = raw.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    return {
      json: {
        // Map parsed fields here
        field_one: parsed.field_one || '',
        field_two: parsed.field_two || 'Default',
        // Always carry upstream identifiers for update/archive steps
        _upstream: upstreamField
      }
    };

  } catch (e) {
    // Never silently drop — write error row
    return {
      json: {
        field_one:   '',
        field_two:   'PARSE_ERROR',
        description: 'ERROR: ' + e.message,
        tag:         'error',
        _upstream:   upstreamField
      }
    };
  }
});
```

---

## CIBC CSV Parse Pattern

CIBC exports have **no header row**. Column order: `Date(YYYYMMDD), Description, Debit, Credit, Balance`

```javascript
const SKIP_KEYWORDS = [
  'TRANSFER', 'INTERAC E-TFR', 'PAYMENT THANK YOU',
  'PAYMENT - THANK', 'INTERNET BANKING', 'PAYROLL',
  'DIRECT DEPOSIT', 'E-TRANSFER RECEIVED'
];

const items = $input.all();
const results = [];

for (const item of items) {
  let csvText = '';
  if (item.binary && item.binary.data) {
    csvText = Buffer.from(item.binary.data.data, 'base64').toString('utf8');
  } else if (item.json.data) {
    csvText = item.json.data;
  }
  if (!csvText) continue;

  const lines = csvText.split('\n').map(l => l.trim()).filter(l => l.length > 0);

  for (const line of lines) {
    const cols = line.match(/(?:"([^"]*)"|([^,]*))/g)
      .map(c => c.replace(/^"|"$/g, '').trim());

    if (cols.length < 4) continue;

    const rawDate  = cols[0];
    const desc     = cols[1];
    const debit    = parseFloat(cols[2]);
    const credit   = parseFloat(cols[3]);

    // Skip credits (refunds/deposits)
    if (!isNaN(credit) && credit > 0) continue;
    if (isNaN(debit) || debit <= 0) continue;

    const descUpper = desc.toUpperCase();
    if (SKIP_KEYWORDS.some(k => descUpper.includes(k))) continue;

    // Format date YYYYMMDD → YYYY-MM-DD
    let date = rawDate;
    if (/^\d{8}$/.test(rawDate)) {
      date = rawDate.slice(0,4) + '-' + rawDate.slice(4,6) + '-' + rawDate.slice(6,8);
    }

    results.push({
      json: { date, raw_description: desc, amount: debit.toFixed(2), source: 'CIBC_CSV' }
    });
  }
}

return results;
```

---

## Connection Format Reference

### Linear chain
```json
"Node A": { "main": [[ { "node": "Node B", "type": "main", "index": 0 } ]] },
"Node B": { "main": [[ { "node": "Node C", "type": "main", "index": 0 } ]] }
```

### If node — two branches
```json
"If Node": {
  "main": [
    [ { "node": "True Branch",  "type": "main", "index": 0 } ],
    [ { "node": "False Branch", "type": "main", "index": 0 } ]
  ]
}
```

### If node — true only, false terminates
```json
"If Node": {
  "main": [
    [ { "node": "Next Node", "type": "main", "index": 0 } ],
    []
  ]
}
```

### One node fans out to two (parallel)
```json
"Source Node": {
  "main": [[
    { "node": "Branch A", "type": "main", "index": 0 },
    { "node": "Branch B", "type": "main", "index": 0 }
  ]]
}
```
