#!/usr/bin/env python3
"""
generate_flowchart.py — Generate a Mermaid flowchart from a workflow JSON file.

Usage:
    python scripts/generate_flowchart.py workflow.json

Output:
    Prints a Mermaid flowchart LR diagram to stdout.
    Redirect to a .mmd file or paste directly into a Mermaid renderer.

Node type detection (by n8n type string):
    trigger   — scheduleTrigger, webhook, manualWorkflowTrigger, googleDriveTrigger
    action    — googleSheets, googleDrive, slack, sendEmail, httpRequest
    logic     — if, switch, filter
    transform — code, set
"""

import json
import sys
from pathlib import Path

# Map n8n type suffix → visual class
TYPE_CLASS = {
    "scheduletrigger":           "trigger",
    "manualworkflowtrigger":     "trigger",
    "webhook":                   "trigger",
    "googledrivetrigger":        "trigger",
    "gmailTrigger":              "trigger",
    "googlesheetsTrigger":       "trigger",
    "googlesheets":              "action",
    "googledrive":               "action",
    "slack":                     "action",
    "sendemail":                 "action",
    "httprequest":               "action",
    "if":                        "logic",
    "switch":                    "logic",
    "filter":                    "logic",
    "code":                      "transform",
    "set":                       "transform",
    "functionItem":              "transform",
}

# Emoji prefix per class for quick visual scanning
CLASS_EMOJI = {
    "trigger":   "🕐",
    "action":    "📊",
    "logic":     "❓",
    "transform": "⚙️",
    "dead":      "🔴",
}

CLASSDEFS = """
    classDef trigger   fill:#1a73e8,color:#fff,stroke:#1558b0,stroke-width:2px
    classDef action    fill:#34a853,color:#fff,stroke:#1e7e34,stroke-width:2px
    classDef logic     fill:#fbbc04,color:#000,stroke:#f09d00,stroke-width:2px
    classDef transform fill:#9334e6,color:#fff,stroke:#6d28d9,stroke-width:2px
    classDef dead      fill:#ea4335,color:#fff,stroke:#c5221f,stroke-width:2px
""".strip()


def slugify(name: str) -> str:
    """Convert node name to a valid Mermaid node ID."""
    return name.replace(" ", "_").replace("-", "_").replace("/", "_").replace("(", "").replace(")", "")


def detect_class(node_type: str) -> str:
    suffix = node_type.split(".")[-1].lower()
    return TYPE_CLASS.get(suffix, "action")


def generate_flowchart(workflow: dict) -> str:
    nodes = workflow.get("nodes", [])
    connections = workflow.get("connections", {})

    # Build node lookup: name → class
    node_map = {}
    for node in nodes:
        name = node["name"]
        cls = detect_class(node.get("type", ""))
        node_map[name] = cls

    lines = ["flowchart LR"]

    # Node definitions
    for node in nodes:
        name  = node["name"]
        cls   = node_map[name]
        slug  = slugify(name)
        emoji = CLASS_EMOJI.get(cls, "")

        if cls == "trigger":
            lines.append(f'    {slug}(["{emoji} {name}"]):::{cls}')
        elif cls == "logic":
            lines.append(f'    {slug}{{"{emoji} {name}"}}:::{cls}')
        else:
            lines.append(f'    {slug}["{emoji} {name}"]:::{cls}')

    lines.append("")

    # Connections
    dead_end_counter = [0]

    for source_name, outputs in connections.items():
        source_slug = slugify(source_name)
        main_outputs = outputs.get("main", [])

        for branch_index, branch in enumerate(main_outputs):
            if not branch:
                # Empty branch — draw dead end
                dead_end_counter[0] += 1
                dead_id = f"END{dead_end_counter[0]}"
                label = "|No|" if len(main_outputs) > 1 and branch_index == 1 else ""
                lines.append(f'    {source_slug} -->{label} {dead_id}(("END")):::dead')
                continue

            for target in branch:
                target_name = target["node"]
                target_slug = slugify(target_name)

                # Add branch labels for If nodes (true=0, false=1)
                if len(main_outputs) > 1:
                    label = "|Yes|" if branch_index == 0 else "|No|"
                else:
                    label = ""

                lines.append(f'    {source_slug} -->{label} {target_slug}')

    lines.append("")
    lines.append("    " + CLASSDEFS.replace("\n", "\n    "))

    return "\n".join(lines)


def main():
    if len(sys.argv) < 2:
        print("Usage: python scripts/generate_flowchart.py <workflow.json>")
        sys.exit(1)

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"Error: File not found: {path}")
        sys.exit(1)

    with open(path) as f:
        workflow = json.load(f)

    chart = generate_flowchart(workflow)
    print(chart)


if __name__ == "__main__":
    main()
