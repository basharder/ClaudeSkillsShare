---
name: n8n-workflow-builder
description: >
  Design, generate, and visualize n8n automation workflows. Use this skill whenever
  the user wants to build a new n8n workflow, design automation logic, generate
  importable workflow JSON, or produce a visual flowchart of a workflow. Trigger on:
  "build me a workflow", "create an n8n automation", "design a workflow", "show me
  a flowchart of", "map out this automation", "generate n8n JSON", "how would I
  automate", "what nodes do I need for", "draw the flow for", or any description of
  a multi-step automation process. Also trigger when the user describes a business
  process they want to automate — even if they don't mention n8n explicitly. This
  skill always produces BOTH a visual Mermaid flowchart AND valid importable JSON.
  Never produce only one without the other unless explicitly asked.
---

# n8n Workflow Builder

Produces two outputs for every workflow request:
1. **Mermaid flowchart** — visual map of the flow rendered inline
2. **Importable workflow JSON** — valid n8n JSON ready to push via API or import via UI

Always deliver both. If the user only asked for one, deliver the other anyway and note it.

---

## Step 1 — Understand Intent

Before building, confirm these four things. Extract from conversation context first — only ask if missing:

| # | Question | Why it matters |
|---|---|---|
| 1 | What triggers the workflow? | Determines trigger node type |
| 2 | What actions happen, in what order? | Determines node sequence |
| 3 | Are there conditionals or branches? | If/Switch nodes required |
| 4 | What credentials exist in their n8n instance? | Placeholder vs real cred IDs |

If the user says "just build it" or gives enough context — proceed. Don't over-question.

---

## Step 2 — Select Nodes

Read `references/node-library.md` for full node templates and parameters before writing JSON.

**Quick trigger selection:**

| Use case | Trigger node |
|---|---|
| Time-based (daily, weekly, cron) | `scheduleTrigger` |
| HTTP call from external system | `webhook` |
| Manual / one-shot | `manualWorkflowTrigger` |
| File dropped in Google Drive | `googleDriveTrigger` |
| New email arrives | `gmailTrigger` |
| New row in Google Sheets | `googleSheetsTrigger` |

**Quick action selection:**

| Use case | Action node |
|---|---|
| Read/write Google Sheets | `googleSheets` |
| Read/write Google Drive | `googleDrive` |
| Call any API or local LLM | `httpRequest` |
| Transform / parse data | `code` (JS) |
| Branch on condition | `if` |
| Multi-branch routing | `switch` |
| Send email | `sendEmail` |
| Slack message | `slack` |
| Set/rename fields | `set` |
| Filter items | `filter` |

---

## Step 3 — Build the Mermaid Flowchart

Generate a Mermaid `flowchart LR` diagram first. This gives the user a visual confirmation before JSON is written.

**Rules:**
- Left-to-right (`flowchart LR`) always
- One box per node, label = display name
- Use `-->` for main flow
- Use `-->|Yes|` and `-->|No|` for If node branches
- Use `-->|Branch N|` for Switch node outputs
- Dead ends (no-op false branches) terminate with `((END))`
- Color-code by node type using `style` declarations (see template below)

**Color codes:**

| Node type | Fill | Stroke |
|---|---|---|
| Trigger | `#1a73e8` / white text | `#1558b0` |
| Action / Integration | `#34a853` / white text | `#1e7e34` |
| Logic (If/Switch/Filter) | `#fbbc04` / black text | `#f09d00` |
| Transform (Code/Set) | `#9334e6` / white text | `#6d28d9` |
| Error / Dead end | `#ea4335` / white text | `#c5221f` |

**Template:**
```
flowchart LR
    A([🕐 Schedule Trigger]):::trigger --> B[📊 Read Sheet]:::action
    B --> C{Has Rows?}:::logic
    C -->|Yes| D[🤖 Call LMStudio]:::action
    C -->|No| Z((END)):::dead
    D --> E[⚙️ Parse Response]:::transform
    E --> F[📊 Append to Sheet]:::action

    classDef trigger fill:#1a73e8,color:#fff,stroke:#1558b0
    classDef action fill:#34a853,color:#fff,stroke:#1e7e34
    classDef logic fill:#fbbc04,color:#000,stroke:#f09d00
    classDef transform fill:#9334e6,color:#fff,stroke:#6d28d9
    classDef dead fill:#ea4335,color:#fff,stroke:#c5221f
```

Render this as a Mermaid artifact so it displays inline.

---

## Step 4 — Build the Workflow JSON

Read `references/node-library.md` for exact node schemas before writing.

**JSON construction rules:**

1. Generate a UUID for every node `id` field — use `python3 -c "import uuid; print(uuid.uuid4())"`
2. Position nodes 250px apart horizontally starting at `[250, 300]`
3. Branch nodes (If/Switch): true branch goes at `[x, 200]`, false at `[x, 400]`
4. Node names must be unique and match exactly between `nodes[]` and `connections{}`
5. Connections reference node **names**, not IDs
6. Always set `"settings": {"executionOrder": "v1"}`
7. Always set `"active": false` — never auto-activate
8. Use `CRED_ID` as credential placeholder — flag each one for the user
9. Use `YOUR_*` placeholders for sheet IDs, folder IDs, URLs — list them all in a setup table

**Connections format:**
```json
"Source Node Name": {
  "main": [[ { "node": "Target Node Name", "type": "main", "index": 0 } ]]
}
```

For If nodes (two outputs):
```json
"If Node Name": {
  "main": [
    [ { "node": "True Branch Node", "type": "main", "index": 0 } ],
    [ { "node": "False Branch Node", "type": "main", "index": 0 } ]
  ]
}
```

---

## Step 5 — Deliver Output

Always structure your response in this order:

### 1. Flow Summary
One sentence — what triggers it, what it does, what it outputs.

### 2. Mermaid Flowchart
Rendered Mermaid artifact (flowchart LR).

### 3. Setup Table
Every placeholder the user must fill in before importing:

| Placeholder | What to replace with |
|---|---|
| `YOUR_SHEET_ID` | Google Sheet ID from URL bar |
| `CRED_ID` | Credential ID from n8n Settings → Credentials |
| `YOUR_LMSTUDIO_HOST:PORT` | Local LMStudio IP and port |

### 4. Workflow JSON
Saved as a `.json` file and presented for download.

### 5. Import Command
Ready-to-copy curl command:
```bash
curl -X POST http://YOUR_N8N_IP:5678/api/v1/workflows \
  -H "X-N8N-API-KEY: YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d @workflow_name.json
```

---

## LMStudio Integration Pattern

When the workflow calls a local LLM (LMStudio), always use this pattern:

```json
{
  "method": "POST",
  "url": "http://YOUR_LMSTUDIO_HOST:PORT/v1/chat/completions",
  "body": {
    "model": "local-model",
    "temperature": 0.1,
    "max_tokens": 512,
    "messages": [
      { "role": "system", "content": "SYSTEM PROMPT HERE" },
      { "role": "user",   "content": "={{ $json.input_field }}" }
    ]
  }
}
```

Always follow the LMStudio HTTP node with a `code` node that:
1. Extracts `choices[0].message.content`
2. Strips markdown fences: `.replace(/```json|```/g, '').trim()`
3. Wraps JSON.parse in try/catch with a fallback error row

See `references/node-library.md` → "LMStudio Parse Pattern" for the full reusable code block.

---

## Error Handling Standards

Every workflow must include at minimum:
- An `if` or `filter` node after the data read step to short-circuit on empty results
- A try/catch in any `code` node that parses LLM or OCR output
- Error rows written to the destination sheet (not silently dropped) with `category: 'PARSE_ERROR'` and `tag: 'error'`

---

## Common Workflow Patterns

For full node JSON templates, see `references/node-library.md`.

| Pattern | Trigger | Key nodes |
|---|---|---|
| Weekly batch processor | Schedule Mon 8AM | Read Sheet → Filter → HTTP (LMStudio) → Code → Append Sheet → Update Sheet |
| Drive file watcher | Google Drive trigger | Download File → Code (parse) → HTTP → Append Sheet |
| CSV importer | Schedule | Drive search → Download → Code (parse CSV) → HTTP (LMStudio) → Append Sheet → Drive move |
| Receipt OCR pipeline | Schedule | Read Ingest Sheet → Filter unprocessed → HTTP (LMStudio) → Code → Append Expense Log → Update Ingest |
| Webhook → Slack alert | Webhook | If (condition) → Slack |

---

## References

- `references/node-library.md` — Full node JSON templates for all common node types. **Read this before writing any JSON.**

---

## Constraints & Reminders

- n8n local IP (`192.168.x.x`) is not reachable from Claude's container — always provide curl command for user to run locally
- Never auto-activate workflows — always set `"active": false`
- Never hardcode API keys — use env vars (`$env.VAR_NAME`) or n8n credential references
- CIBC CSV format: no header row, columns are `Date(YYYYMMDD), Description, Debit, Credit, Balance`
- Google Sheets `update` operation matches on a column value — always include `matchingColumns` in the parameters
- WeasyPrint is incompatible with CSS grid — use ReportLab for PDF generation if needed
